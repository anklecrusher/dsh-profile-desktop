// Permissions. A Bot's permission preset is its own: kept on the Bot and set on every
// Session it speaks from, so a fresh part or a new group Session keeps it. A group may
// set one preset for all its members there, in place of each member's own, as it may
// set one working folder.
// DSH offers Auto review for the current Session only, so neither a Bot nor a group keeps it.
const SESSION_ONLY = 'auto'

export function install(rt) {
  const { ctx } = rt

  const presets = () => ctx.get?.('permissionPresets')
  let pending = Promise.resolve()
  // A Session becomes visible under the same lock that changes its inherited preset.
  function withPermissions(action) {
    const result = pending.then(action)
    pending = result.catch(() => {})
    return result
  }

  // The presets DSH offers, or undefined when the profile has none.
  function permissionCatalog() {
    const service = presets()
    if (service === undefined) return undefined
    const { options, defaultPreset } = service.catalog()
    return { options: options.filter(option => option.value !== SESSION_ONLY), defaultPreset }
  }

  const roomOfSession = sessionId => rt.roomOf(rt.groupOwners.get(sessionId)?.roomId)

  async function setPreset(sessionId, name) {
    const agent = await rt.resolveAgent(sessionId)
    await presets().set(agent.session, name)
  }

  // Sets the preset on one of the Bot's Sessions: its group's there, else its own; a Bot
  // without one keeps DSH's default. `room` is for a group Session not indexed yet.
  async function applyPermission(bot, sessionId, room = roomOfSession(sessionId)) {
    const name = room?.permission ?? bot.permission
    if (!name) return
    if (presets() === undefined) throw new Error('Permissions are not available in this DeepSeek Harness')
    await setPreset(sessionId, name)
  }

  function checkPreset(name, whose) {
    const service = presets()
    if (service === undefined) throw new Error('Permissions are not available in this DeepSeek Harness')
    const wanted = String(name ?? '').trim()
    if (wanted === SESSION_ONLY) throw new Error(`Auto review applies to one Session only and cannot be ${whose} permission`)
    service.resolve(wanted)
    return wanted
  }

  async function setPermission(bot, name) {
    const wanted = checkPreset(name, 'a Bot\'s')
    const service = presets()
    const targets = []
    try {
      const sessionIds = new Set([rt.chatOf(bot.id), ...rt.groupSessionsOf(bot.id)])
      for (const sessionId of sessionIds) {
        if (sessionId !== rt.chatOf(bot.id) && roomOfSession(sessionId)?.permission) continue
        targets.push((await rt.resolveAgent(sessionId)).session)
      }
    } catch (cause) {
      throw new Error(`Could not apply permissions to ${bot.name} in every conversation. Some may already have changed; retry the permission setting.`, { cause })
    }
    for (const session of targets) {
      try {
        await service.set(session, wanted)
      } catch (cause) {
        throw new Error(`Could not apply permissions to ${bot.name} in every conversation. Some may already have changed; retry the permission setting.`, { cause })
      }
    }
    bot.permission = wanted
  }

  // A group's preset, or null when each member uses its own.
  const cleanRoomPermission = name => (name === null || name === '' ? null : checkPreset(name, 'a group\'s'))

  // Members' Sessions in the group change now; a member that has none there yet gets the
  // group's preset when its first turn there makes one. Returns whether it changed.
  async function setRoomPermission(room, name) {
    const wanted = cleanRoomPermission(name) ?? undefined
    const changed = wanted !== room.permission
    const service = presets()
    if (service === undefined) throw new Error('Permissions are not available in this DeepSeek Harness')
    const members = []
    for (const [botId, sessionId] of Object.entries(room.sessions ?? {})) {
      const bot = rt.botOf(botId)
      if (bot === undefined) continue
      const next = wanted ?? bot.permission ?? service.catalog().defaultPreset
      service.resolve(next)
      const agent = await rt.resolveAgent(sessionId)
      members.push({ bot, session: agent.session, next })
    }
    // Resolve every Session first. Do not roll back already applied restrictions if a
    // later write fails; leave the setting uncommitted and allow any preset to retry.
    for (const { bot, session, next } of members) {
      try { await service.set(session, next) }
      catch (cause) { throw new Error(`Could not apply group permissions to ${bot.name}. Some members may already have changed; retry the permission setting.`, { cause }) }
    }
    if (wanted === undefined) delete room.permission
    else room.permission = wanted
    return changed
  }

  Object.assign(rt, {
    permissionCatalog, applyPermission, cleanRoomPermission, withPermissions,
    setPermission: (bot, name) => withPermissions(() => setPermission(bot, name)),
    setRoomPermission: (room, name) => withPermissions(() => setRoomPermission(room, name)),
  })
}
